﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hierarchie_de_classes
{
    public interface ITruck: IRoadVehicle
    {
        int MaxFreight();
    }
}
